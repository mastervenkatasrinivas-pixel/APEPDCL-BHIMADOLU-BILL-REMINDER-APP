package in.apepdcl.billreminder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val API_BASE_URL = "https://YOUR-SECURE-SERVER.example/"
private const val API_KEY = "REPLACE_WITH_EMPLOYEE_SESSION_TOKEN"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { BillReminderScreen() } }
    }
}

@Composable
private fun BillReminderScreen() {
    var service by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("వివరాలు నమోదు చేయండి") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("APEPDCL BHIMADOLU", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text("BILL REMINDER", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("భీమడోలు సెక్షన్ – తెలుగు ఆటోమేటిక్ బిల్ రిమైండర్", style = MaterialTheme.typography.bodyLarge)
        HorizontalDivider()
        OutlinedTextField(service, { service = it }, label = { Text("Service Number") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(name, { name = it }, label = { Text("Consumer Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(mobile, { mobile = it.filter(Char::isDigit).take(10) }, label = { Text("Mobile Number") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(amount, { amount = it }, label = { Text("Pending Amount (₹)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("వాయిస్ సందేశం", fontWeight = FontWeight.SemiBold)
        Text("నమస్కారం. మీ విద్యుత్ సర్వీసుకు సంబంధించిన కరెంట్ బిల్లు పెండింగ్‌లో ఉంది. దయచేసి బిల్లు చెల్లించగలరు. ధన్యవాదాలు.")
        Row {
            Checkbox(checked = consent, onCheckedChange = { consent = it })
            Text("ఈ రిమైండర్ కాల్‌కు అవసరమైన సమ్మతి / అధికార అనుమతి నిర్ధారించాను.", modifier = Modifier.padding(top = 12.dp))
        }
        Button(
            onClick = {
                val parsedAmount = amount.toDoubleOrNull()
                if (service.isBlank() || mobile.length != 10 || parsedAmount == null || parsedAmount < 0) {
                    status = "Service Number, సరైన 10 అంకెల Mobile Number, Amount నమోదు చేయండి."
                } else if (!consent) {
                    status = "ముందుగా అనుమతి / సమ్మతి నిర్ధారించండి."
                } else if (API_BASE_URL.contains("YOUR-SECURE-SERVER")) {
                    status = "Backend URL మరియు API authentication ఇంకా configure చేయలేదు."
                } else {
                    busy = true
                    status = "Cloud server‌ను సంప్రదిస్తున్నాం..."
                    scope.launch {
                        status = sendCallRequest(service, name, mobile, parsedAmount)
                        busy = false
                    }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "దయచేసి వేచి ఉండండి..." else "CALL REMINDER") }
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(status, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
        }
        Text("గమనిక: నిజమైన కాల్ కోసం అధికారిక Cloud Telephony provider integration అవసరం.", style = MaterialTheme.typography.bodySmall)
    }
}

private suspend fun sendCallRequest(
    service: String, name: String, mobile: String, amount: Double
): String = withContext(Dispatchers.IO) {
    try {
        val json = JSONObject().apply {
            put("serviceNumber", service.trim())
            put("consumerName", name.trim())
            put("mobileNumber", mobile)
            put("pendingAmount", amount)
            put("language", "te")
            put("consentConfirmed", true)
        }
        val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
        val body = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(API_BASE_URL.trimEnd('/') + "/api/calls")
            .addHeader("x-api-key", API_KEY)
            .post(body)
            .build()
        client.newCall(request).execute().use { response ->
            val responseText = response.body?.string().orEmpty()
            if (!response.isSuccessful) "Server error: HTTP ${response.code}"
            else {
                val result = JSONObject(responseText)
                when (result.optString("status")) {
                    "provider_not_configured" -> "Backend సిద్ధంగా ఉంది; Cloud Calling provider ఇంకా configure చేయాలి."
                    "queued" -> "కాల్ అభ్యర్థన queue అయింది. Call ID: ${result.optString("callId")}"
                    else -> result.optString("message", "Server response అందింది.")
                }
            }
        }
    } catch (e: Exception) {
        "కనెక్షన్ సమస్య: ${e.message ?: "తెలియని లోపం"}"
    }
}
